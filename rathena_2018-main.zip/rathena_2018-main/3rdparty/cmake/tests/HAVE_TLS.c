__thread int tls;

int main(int argc, char** argv)
{
	return 0;
}
